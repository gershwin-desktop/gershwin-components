# Software Update (git) — handoff bundle

Final design of a GNUstep "Software Update" application for Gershwin that keeps a
source-built system in sync with the gershwin-desktop repositories.

## Contents

| Path | What it is |
|---|---|
| `SPEC.md` | The specification: overview + one section per screen, with screenshots. **Start here.** |
| `screens/` | PNG screenshots (2x) of every screen, incl. the Details-open variants and the Log window. |
| `icons/` | App, alert and status icons as PNG (1x and `@2x`) plus SVG sources. |
| `mockups/` | Raw design-canvas source of each screen. Reference only: they need the design tool's runtime to render and contain web CSS. Do not port them. |

## Kickoff prompt for Claude Code

> Read `docs/software-update/README.md` and `SPEC.md` completely, and look at every
> screenshot in `screens/`. Then read the relevant parts of gershwin-developer
> (`Library/Scripts/checkout.sh`, `bootstrap.sh`, `patch.sh`, `install-system-domain.sh`,
> `Library/OSSupport/`, `Library/Patches/`) and gershwin-components (`PackageManager`,
> `OnDemand`, `SudoAskPass`) before writing code. Propose a plan (targets, classes,
> which existing code to reuse or factor out, which changes are needed in other
> repositories) and wait for my OK before implementing. Treat all data in the
> screenshots as sample data.

## Decisions still open (confirm before implementation)

1. Where the app lives (gershwin-components or its own repository), its install
   location and how it is launched (menu entry).
2. Moving the repository list, order, pins, restart flags and targets from
   `checkout.sh` into a plist in gershwin-developer (e.g. `Library/Repositories.plist`),
   with `checkout.sh` reading it too.
3. Giving `install-system-domain.sh` separate build and install modes.
4. An environment variable so SudoAskPass can name the requesting app, and the
   restyling of SudoAskPass.
5. Automatically rebuilding later repositories after a core library is rebuilt.
6. Which repositories count as "restart required".

## Sample data in the screenshots (do not hard-code)

GitHub build states (textedit failed, components running), which libraries have
a changed commit (libs-gui, libs-back), the three missing packages, local changes
and the stash conflict (`TerminalView.m`), progress percentages and time estimates.
Commit headlines and hashes were real at design time but will be outdated.

## Not verified during design

- The internals of OnDemand's log window and of PackageManager (only their
  existence is known) — read the code.
- `patch.sh`, `bootstrap.sh` and `install-system-domain.sh` were read via summaries;
  re-read them.
- The `OSSupport` file naming (`<os-id>.txt`, e.g. `freebsd.txt`) was inferred
  from one file.

## Guardrails

- Real GNUstep controls, themed by gershwin-eau-theme; all sizes and fonts from
  AppearanceMetrics; no monospaced fonts anywhere; no hand-drawn Aqua.
- Nothing about repositories, order or pins hard-coded — always from gershwin-developer.
- Reuse PackageManager (distribution packages) and OnDemand (log window, task
  running) instead of re-implementing them.
- Privileged work (packages, `make install`) runs as root via `sudo -A` +
  SudoAskPass; test Stop, rollback and stash handling on a throwaway VM first.
