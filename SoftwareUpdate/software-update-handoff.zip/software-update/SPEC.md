# Software Update (git) — specification

Final design for a GNUstep Software Update application for Gershwin. Screenshots are in `screens/`, icons in `icons/`. The screenshots are web mockups: build the UI with real GNUstep/AppKit controls themed by gershwin-eau-theme and sized from AppearanceMetrics — do not imitate the mockup CSS.

All repository names, commits, build states, packages and conflicts shown in the screenshots are **sample data**; never hard-code them.


## Software Update (git) — overview

*Developer notes · read first*

A GNUstep application that keeps a Gershwin system that was built from source in sync with the gershwin-desktop repositories. Flow: **check → choose → authenticate → install → summary**. The window never shows shell jargon unless the user opens Details.


### Where things live

- `/Developer` is the gershwin-developer clone. Sources are in `/Developer/Library/Sources/<repo>`.
- Prerequisite package lists: `/Developer/Library/OSSupport/<os-id>.txt` (same OS detection and package manager mapping as `Library/Scripts/bootstrap.sh`).
- Patches: `/Developer/Library/Patches/<repo>/*.patch`, applied with `Library/Scripts/patch.sh <repo>` (patch -p1 -N; already-applied patches count as applied).
- Build and install: the same code paths as `make <target>` / `Library/Scripts/install-system-domain.sh`. These run as root.

### Source of truth: gershwin-developer

**Which repositories are used, in which order, which upstream libraries are pinned (and to which commit), which have patches and which build targets they map to is determined by gershwin-developer — never hard-coded in Software Update.** Today that information lives in `Library/Scripts/checkout.sh`. It is fine (and preferred) to move it into a property list in gershwin-developer, e.g. `Library/Repositories.plist`, as long as checkout.sh reads its list from there too, so there is exactly one place to change.


```text
{
  Repositories = (
    { Name = gershwin-developer; URL = "https://github.com/gershwin-desktop/gershwin-developer.git"; },
    { Name = swift-corelibs-libdispatch; URL = "…"; Pin = 95f592a; },
    { Name = libobjc2; URL = "…"; Pin = c9f4002; },
    …
    { Name = gershwin-system; URL = "…"; RestartRequired = YES; },
    …
  );
}
```

- Suggested keys per entry: Name, URL, Pin (commit; absent = follows a branch), RestartRequired, Target (make target). Patches stay discoverable by folder: `Library/Patches/<Name>/`. Software Update reads the plist with NSPropertyListSerialization; checkout.sh can read it with `plutil`/`defaults` or a tiny helper.

### Repository order

Always **gershwin-developer first** (it holds that list, the pins, patches, prerequisites and build scripts), then the order it defines — currently:


```text
gershwin-developer
swift-corelibs-libdispatch, libobjc2, tools-make, libs-base,
libs-gui, libs-back, libs-av, libs-steptalk        (pinned)
gershwin-system, gershwin-workspace, gershwin-systempreferences,
gershwin-eau-theme, gershwin-terminal, gershwin-textedit,
gershwin-windowmanager, gershwin-components, gershwin-assets, docs
```

- Read the list and pins from gershwin-developer (the plist, or checkout.sh until the plist exists) at run time. After gershwin-developer has been updated, re-read it and rebuild the plan.
- **Pinned upstream libraries** (swift-corelibs-libdispatch, libobjc2, tools-make, libs-base, libs-gui, libs-back, libs-av, libs-steptalk) come right after gershwin-developer and before the Gershwin repositories. Each is checked out at exactly the commit pinned by gershwin-developer (repository list plist or `Library/Scripts/checkout.sh`) (`git fetch` then `git checkout --detach <pin>`), patched from `Library/Patches/<repo>/` where present, then built and installed. They never follow a branch; the Development checkbox and the GitHub build check do not apply.
- Read the pins from the **incoming** version of gershwin-developer (`git -C /Developer show origin/<target>:Library/Repositories.plist`, or checkout.sh) during the check, so the list already reflects pins that change with this update. A pinned library is listed only when its HEAD differs from the pin.

### One update run


```text
1  Update gershwin-developer          (if selected)
2  Install prerequisites               (once per run)
3  Check out pinned upstream libraries at their pins,
   then each selected Gershwin repository, in order:
     stash → check out & pull → apply patches
     → build → install → re-apply stash
4  Stash warnings (if any) → completion / restart
```

- Rebuilding a core library (tools-make, libobjc2, libs-base, libs-gui, libs-back) or gershwin-system means everything after it must be rebuilt as well. Suggestion: add those later repositories to the run as “rebuild only” steps without pulling.

### Appearance metrics

- All sizes, fonts and spacing come from **AppearanceMetrics** in gershwin-eau-theme; never hard-code them in Software Update or SudoAskPass. The mockups follow it: message text System Font 13 pt (bold for the alert headline), informative and detail text 11 pt, buttons 20 px high and at least 100 px wide with 12 px between them, text fields 22 px high, window margins 15 px top, 24 px sides, 20 px bottom, windows at least 500 px wide. **No monospaced fonts anywhere**, including branch names, commit hashes and the Log window.

### Reuse from gershwin-components

Do not re-implement what already exists in **gershwin-components**. Before writing new code, study and reuse (or factor out into a shared framework/library) the relevant parts of:

- **PackageManager**: everything that deals with distribution packages: detecting the OS and its package manager, checking whether a package is installed, installing missing ones, reporting progress and errors. Use it for the prerequisites from gershwin-developer’s `Library/OSSupport/<os-id>.txt` instead of new per-OS shell code.
- **OnDemand**: its log window (shown with ⌘L) and its way of running long jobs with progress; model the Software Update Log window and task runner on it.
- If the needed functionality is buried inside those apps, move it into a shared component first so all three apps use the same code.

### Implementation notes

- All git, package manager and make work runs off the main thread (NSOperationQueue or a worker NSThread using NSTask). UI updates go through `performSelectorOnMainThread:`; the run loop is never blocked.
- Preferences in NSUserDefaults: `UseDevelopmentBranch` (BOOL, default NO), `LastCheckDate`, and per-repository build durations for time estimates.
- Every command and its output goes to the **Log window**, opened with the menu item **Show Log** (⌘L), like the OnDemand app in gershwin-components, and is also appended to a log file. Progress windows never show raw command output.
- The GUI runs as the user. Privileged work (package installs, make install, git in root-owned trees) runs in one helper process started after authentication.

## Checking for new commits

*Screen 1 · behavior*

![01-checking](screens/01-checking.png)

Shown on launch and for “Check Now”. A small window with an indeterminate (barber-pole) NSProgressIndicator and a status line “Fetching <repo> from origin (n of N)”.


### Per repository, in list order


```text
git -C <src> fetch --prune origin
git -C <src> rev-parse --abbrev-ref HEAD           # current branch
git -C <src> ls-remote --heads origin dev         # dev exists?
git -C <src> rev-list --count HEAD..origin/<target>
git -C <src> log --format=%h%x09%s%x09%as HEAD..origin/<target>
git -C <src> status --porcelain --untracked-files=no
```

- `<target>` is `dev` when “Use Development branch” is on and origin has a dev branch; otherwise the default branch (`origin/HEAD`, e.g. main or master).
- Fetch both default and dev branches, so toggling the checkbox later needs no network.
- GitHub build status: `GET /repos/gershwin-desktop/<repo>/commits/<sha>/check-runs` for the tip of `origin/<target>`. Store one of: passed, failed, running (queued or in progress), unknown. Cache the answer per sha; unauthenticated API calls are rate-limited.

### Outcomes

- Nothing new anywhere → “Your software is up to date” window.
- Something new → the main window (screen 2).
- A fetch fails (offline, host unreachable) → keep going with the others; the failed repository is listed as “Couldn’t check” (unselectable). If every fetch fails, show an alert saying Software Update can’t reach GitHub.
- Stop cancels the remaining fetches and shows what was found so far.

## Repositories with new commits

*Screen 2 · behavior*

![02-main](screens/02-main.png)

The main window. At most **800 px wide**; the height may grow. Plain Aqua-grey background, no pinstripes. Icon: git symbol (deep blue diamond, white branch) inside a lighter blue circular updater arrow; all shades of blue, no black, not too vibrant.


### Layout (top to bottom)

- Header: icon, bold headline, one short explanatory line.
- NSSplitView (horizontal divider): NSTableView of repositories on top, details below.
- Bottom bar: “Use Development branch (dev)” switch button, summary line, Quit, and the default button “Update N Repositories” (pulses like a default button; Return activates it).

### Table

- Columns: Install (switch cell) · Repository · Branch · Commits. Nothing else: no build-status or flag columns.
- Only repositories with something to install are listed, in the overview order. Up-to-date ones are counted in the summary line.
- Branch: `main`, or `main → dev` when the checkout will switch branches, or just the commit (`8f804fd`) for pinned upstream libraries. Repos with no dev branch show their default branch unchanged.
- Pinned upstream libraries sit between gershwin-developer and the Gershwin repositories. Commits column: “new”. The word “pin” never appears in the UI (too technical); it is only used in these notes. Their checkbox always mirrors gershwin-developer’s and cannot be toggled on its own (the pins belong to that version of gershwin-developer). Details pane: which commit they are pinned to, by which script, and whether patches apply; no commit list.
- Restart requirement and local changes are not shown in the table. Restart is announced in the confirmation sheet; local changes are shown in the details pane of the selected repository.

### Selection rules

- **Build passed or unknown:** row enabled and checked by default.
- **Build failed or still running** (GitHub check runs): row unchecked, checkbox disabled, text in disabledControlTextColor, and the reason follows the name in the Repository cell: “— Build failed on server, please retry later” or “— Build still in progress on server, please retry later”. The row can still be selected so its details can be read. Unknown build status is treated like passed.
- User choices are kept for the session only; the next check starts from these defaults again.

### Details pane

- Repository name, `origin/<target> · N new commits`.
- If blocked: a red line naming the sha and why (failed / still running).
- If dirty: an amber line with the number of modified files that will be stashed.
- Commit list, newest first: short sha (system font, grey), subject, date. Read-only, scrollable.

### Development branch checkbox

- Stored in NSUserDefaults as `UseDevelopmentBranch`. Toggling recomputes target branch, commit lists and build status for every non-pinned repository from the data already fetched (show a small spinner while it runs), then re-applies the selection rules.

### Update button

- Title “Update N Repositories”; disabled and titled “Update” when nothing is checked.
- Shows a sheet: restart warning if any selected repo needs a restart, branch-switch warning when dev is on, local-changes note. Cancel returns; Update continues to authentication.
- Quit closes the application without changing anything.

## Authenticate (SudoAskPass)

*Screen 3 · behavior*

![03-authenticate](screens/03-authenticate.png)

This is the existing **SudoAskPass** tool from gershwin-components (`/System/Library/Tools/SudoAskPass`), restyled to look like this panel. Software Update does not draw its own password panel.


### How it is used

- The privileged helper is started with `SUDO_ASKPASS=/System/Library/Tools/SudoAskPass sudo -A <helper>`. sudo launches SudoAskPass, which prints the password on stdout.
- Ask once per run, after the user confirms the update and before anything on disk changes. The helper then performs the whole run as root and streams progress back.
- sudo does not always pass `SUDO_COMMAND` to askpass programs. Suggestion: Software Update sets its own variable (e.g. `ASKPASS_REQUESTER="Software Update"`) so the headline can name the requesting application.

### Changes needed in SudoAskPass

- Window title “Authenticate”; floating panel above other windows, centered.
- Lock icon at left; bold headline “<App> requires that you type your password.”
- Name field: current user, read-only. Password: NSSecureTextField with initial focus.
- Details disclosure (collapsed by default): requesting app and what will run as root.
- Buttons Cancel and OK (default, pulsing). Esc = Cancel, Return = OK.
- Wrong password: the panel shakes and the field is cleared (sudo calls askpass again). Cancel or three failures: Software Update returns to the main window with nothing changed.

## Install prerequisites

*Screen 4 · behavior*

![04-prerequisites](screens/04-prerequisites.png)

![04-prerequisites-details](screens/04-prerequisites-details.png)

Runs once per run, **after** gershwin-developer has been updated (so the package list is current) and before any other repository is touched. The same progress window is used for the whole run.


### Window content

**Progressive disclosure.** By default the window shows only: headline, determinate progress bar, one status line, the Details disclosure triangle and Stop. No checkmark lists.

- Status line: what is happening now, left (“Installing freerdp (package 2 of 3)”); time estimate, right. Updated as each package starts.
- Details, **collapsed by default** (state remembered in defaults), reveals **one** box: the three run phases with done / running / pending marks, and the items of the running phase indented beneath it (here: one row per missing package). Items of finished or pending phases are not listed.
- Opening Details grows the window downward; closing it shrinks it back.
- No command output and no hint about it in this window; the log is reached only through the menu item Show Log (⌘L).

### Steps

- **Reuse PackageManager from gershwin-components** for all distribution-package work (OS/package-manager detection, installed-check, install, progress, errors) rather than writing new per-OS code. The table below only documents what the existing scripts do today.
- Detect the OS the same way bootstrap.sh does and read `Library/OSSupport/<os-id>.txt`.
- Check each package; collect the missing ones; install them. If nothing is missing, the phase completes at once.

```text
FreeBSD/GhostBSD   pkg info -e …        pkg install -y …
Debian/Devuan      dpkg-query -W …      apt-get update; apt-get install -y …
Arch/Artix         pacman -Qi …         pacman -S --noconfirm …
OpenBSD            pkg_info …           pkg_add -I …
Void               xbps-query …         xbps-install -Sy …
```

- To report per-package progress, install one package per command, or parse the package manager output.

### Errors

- If the package manager fails, stop the run before any other repository changes. Show an alert naming the package, with a “Show Log” button (opens the Log window), then return to the main window.
- Stop waits for the package manager to finish its current transaction; never kill it halfway.

## Update each repository

*Screen 5 · behavior*

![05-update](screens/05-update.png)

![05-update-details](screens/05-update-details.png)

Same window as screen 4. Headline “Updating <repo>…”, progress bar (completed steps ÷ all steps of the run), “Repository n of N”, time estimate from stored per-repository durations (omit if no history).


### Window content

**Progressive disclosure**, exactly as screen 4: headline, progress bar, one status line, Details (collapsed), Stop. No checkmark lists unless Details is open.

- Status line: “<Step verb> <repo> (repository n of N)”, e.g. “Building gershwin-workspace (repository 2 of 6)”; verbs: Stashing changes in, Checking out, Patching, Building, Installing, Re-applying changes in.
- Details reveals **one** box: the three run phases, and under “Update repositories” one indented row per selected repository (done / running / pending). The running repository shows its current step at the right. The individual steps are not listed; everything else is in the Log window.

### Steps for one repository


```text
1 Stash        git stash push -m "Software Update <date>"   (only if dirty)
2 Check out    git switch <target>   (create tracking branch if needed)
               git merge --ff-only origin/<target>
3 Patches      Library/Scripts/patch.sh <repo>   (only if Library/Patches/<repo>/ exists)
4 Build        $MAKE -j$CPUS          (as install-system-domain.sh does)
5 Install      $MAKE install
6 Re-apply     revert patched files, then git stash pop
```

- A step that does not apply (no local changes, no patches) is skipped silently; the status line never shows it.
- Remember the old HEAD before step 2 so the repository can be rolled back.
- Before step 6, remove the patch changes (`patch -R` or `git checkout -- <patched files>`) so only the user’s own changes come back.
- Suggestion: give install-system-domain.sh separate build and install modes.

### Failures

- **Fast-forward impossible** (local commits): skip, restore the stash, report in the summary.
- **Patch, build or install fails:** switch back to the old HEAD, pop the stash, report it. For gershwin-developer, gershwin-system or a core library, stop the whole run; otherwise continue.
- **Stash cannot be re-applied:** `git stash pop` keeps the stash on conflict. Collect conflicted files (`git diff --name-only --diff-filter=U`), restore a clean tree with `git reset --merge`, continue. Never drop the stash.

### Stop button

- Asks for confirmation in a sheet, terminates the running NSTask, rolls back the current repository. Finished repositories stay updated.

## Log window

*Menu: Show Log · ⌘L*

![06-log-window](screens/06-log-window.png)

All command lines and their output are shown only here, never in the progress windows. Reuse the log window of the OnDemand app in gershwin-components (share the code rather than copying it).

- Separate NSPanel/NSWindow titled “Software Update Log”, resizable, remembers its frame. Hidden by default and never advertised in the dialogs: the only entry point is the menu item **Show Log** (⌘L; title changes to Hide Log while open), available at any time, also while checking.
- Read-only NSTextView in the regular system font (no monospaced font). Commands prefixed with `$` (user) or `#` (root), followed by their stdout and stderr in arrival order.
- Auto-scrolls to the end unless the user has scrolled up; resumes when scrolled back to the bottom.
- Keeps the whole session; the same text is appended to a log file on disk. The “Show Log” buttons in error alerts open this window and scroll to the failing command.

## Local changes not re-applied

*Screen 6 · behavior*

![07-stash-alert](screens/07-stash-alert.png)

Shown after the last repository finishes, before the completion window, when one or more stashes could not be re-applied. Plain alert: icon, bold message text, informative text, buttons. No boxes or lists.

- Message: “Your local changes to <repo> could not be re-applied.” With several repositories: “Your local changes to N repositories could not be re-applied.”
- Informative text names the conflicting file(s) and the stash message, and says nothing was lost. For several repositories, list them in the sentence (“gershwin-terminal and gershwin-textedit”).
- Buttons: Show in Workspace (opens the repository folder), Open in Terminal (at that folder), Continue (default) → completion window. The stash is never dropped automatically.

## Installation complete

*Screen 7 · behavior*

![08-complete](screens/08-complete.png)

One row per repository processed in this run, in run order. The right-hand column is **empty for normal results** and only shows exceptions.

- Green check, no note: updated normally (including local changes re-applied).
- Warning triangle + note: “local changes kept in stash”.
- Red cross + note: “build failed”, “patch failed” or “diverged, not updated”; the row offers Show Log.
- If anything needing a restart was installed: “You must restart your computer to finish updating”, buttons Later and **Restart** (default). Otherwise a single **Quit** button.
- Restart asks the session to restart through its usual mechanism. Later quits Software Update and stores `LastUpdateDate`.
